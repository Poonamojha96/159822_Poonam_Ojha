package org.xyz.view;

import org.xyz.util.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import org.xyz.modal.*;

public class UserInteraction {

	Utility utility=new Utility();
	
	Scanner scan = new Scanner(System.in);
	
	public Customer getCustomerDetails()
	{
		Customer customer=new Customer();
		
		
		
		int customerId=utility.generateRandomNumber();
		customer.setCustomerId(customerId);
		
		String fname= promptFirstName();
		customer.setFirstName(fname);
		
		String lname= promptLastName();
		customer.setLastName(lname);
		
		String emailId=promptEmailId();
		customer.setEmailId(emailId);
		
		customer.setMobileNo(promptMobileNo());
		
		customer.setDateOfBirth(promptDateOfBirth());
		
		customer.setAddress(promptAddress());
		return customer;
		
	}
	
	public void printCustomerDetails(List<Customer> customer)
	{
		Customer customer1= getCustomerDetails();
		
		System.out.println(customer1.getCustomerId()
				+"\t\t"+customer1.getFirstName()+" " + customer1.getLastName()
				+"\t"+ customer1.getEmailId() + "\t" + customer1.getMobileNo() );
			
	}

	private Address promptAddress() {
		
		System.out.println("Enter Address Line 1");
		String addressLine1=scan.next();
		System.out.println("Enter Address Line 2");
		String addressLine2=scan.next();
		System.out.println("Enter City");
		String city=scan.next();
		System.out.println("Enter State");
		String state=scan.next();
	
		boolean flag=false;
		String pin;
		do {
			System.out.println("Enter PinCode of 6 digits");
			 pin=scan.next();
			flag=Utility.isValidPinCode(pin);
			if(!flag)
				System.out.println("Enter a valid Pincode of 6 digits");
	
		}while(!flag);
		int pinCode=Integer.parseInt(pin);
		Address address= new Address(addressLine1,addressLine2,city,state,pinCode);
		
		
		return address;
	}

	private LocalDate promptDateOfBirth() {
		
		boolean flag=false;
		
		String dob;
		do {
			System.out.println("Enter date of birth[DD/MM/YYYY]");
			dob=scan.next();
			flag=Utility.isValidDateOfBirth(dob);
			if(!flag)
				System.out.println("Enter a valid date of birth[DD/MM/YYYY]");
	
		}while(!flag);
		String[] dateParts=dob.split("/");
		return LocalDate.of(Integer.parseInt(dateParts[2]), 
							Integer.parseInt(dateParts[1]), 
							Integer.parseInt(dateParts[0])); 
	}

	private String promptMobileNo() {
		
		boolean flag=false;
		String mobile;
		do {
			System.out.println("Enter 10 digit mobile number");
			mobile=scan.next();
			flag=Utility.isValidMobileNumber(mobile);
			if(!flag)
				System.out.println("Enter a valid mobile number");
	
		}while(!flag);
		
		return mobile;
	}

	private String promptEmailId() {

		boolean flag=false;
		String email;
		do {
			System.out.println("Enter email id");
			 email=scan.next();
			flag=Utility.isValidEmailId(email);
			if(!flag)
				System.out.println("Enter a valid email id");
	
		}while(!flag);
		
		return email;
	}

	public String promptFirstName() {
		
		boolean flag=false;
		String fname;
		do {
			System.out.println("Enter first name");
			 fname=scan.next();
			flag=Utility.isValidFirstName(fname);
			if(!flag)
				System.out.println("Enter a valid first name");
	
		}while(!flag);
		
		return fname;
	}
	
	public String promptLastName() {
		
		boolean flag=false;
		String lname;
		do {
			System.out.println("Enter last name");
			 lname=scan.next();
			flag=Utility.isValidLastName(lname);
			if(!flag)
				System.out.println("Enter a valid last name");
	
		}while(!flag);
		
		return lname;
	}

	public void printError(String message) {
		
		System.out.println(message);
		
	}
	
	
}
