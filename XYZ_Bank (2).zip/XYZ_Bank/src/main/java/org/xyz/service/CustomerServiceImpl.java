package org.xyz.service;

import java.time.LocalDate;
import java.util.List;

import org.xyz.dao.CustomerDaoImpl;
import org.xyz.modal.Customer;

public class CustomerServiceImpl implements ICustomerService {

	CustomerDaoImpl customerDao= new CustomerDaoImpl();
	
	
	@Override
	public List<Customer> getAllCustomers() {
		
		return customerDao.getAllCustomers();
	}

	@Override
	public void createCustomer(Customer customer) {
		
		if(isValidCustomer(customer))
			customerDao.createCustomer(customer);
		
		
		
	}

	private boolean isValidCustomer(Customer customer) {
		
		boolean flag=false;
		
		if(customer.getMobileNo().matches("(9|8|7)\\d{9}"))
			if(customer.getDateOfBirth().isBefore(LocalDate.now()))
				flag=true;
			else
				flag=false;
		else
			flag=false;
			
		return flag;
	}
	public Customer findCustomerId(int customerId)
	{
		List<Customer> customers=customerDao.getAllCustomers();
		
		Customer cust=null;
		for(Customer customer:customers)
		{
			if(customerId==customer.getCustomerId())
				cust=customer;
				break;
		}
		return cust;
		
		
		
	}
	

	
}
