package org.xyz.service;

import java.util.List;

import org.xyz.modal.Customer;

public interface ICustomerService {

	public List<Customer> getAllCustomers();
	
	public void createCustomer(Customer customer);
}
