package org.xyz.modal;

public enum AccountType {

	SAVINGS,CURRENT,RD,FD;
}
