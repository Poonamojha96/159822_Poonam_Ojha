package org.xyz.boot;

import java.util.List;
import java.util.Scanner;

import org.xyz.modal.Customer;
import org.xyz.service.CustomerServiceImpl;
//import org.xyz.service.ICustomerService;
import org.xyz.view.UserInteraction;

public class BootClass {

	private static List<Customer> customer;

	static Scanner scan= new Scanner(System.in);
	
	public static void main(String[] args) {
		
		CustomerServiceImpl customerService=new CustomerServiceImpl();
		UserInteraction userInteraction= new UserInteraction();
		char c;
		int option;
		
		do {
			System.out.println("1.Create Customer");
			System.out.println("2.List Customers");
			System.out.println("Enter Your choice:");
			int choice=scan.nextInt();
			if(choice==1)
			{
				Customer customer;
				int count=customerService.getAllCustomers().size();
				customer=userInteraction.getCustomerDetails();
				customerService.createCustomer(customer);
				count++;
				
				if(count==customerService.getAllCustomers().size())
					userInteraction.printError("Customer Creation Error! Please Try Again!");
				
			}
			else if(choice==2)
			{
				List<Customer> customers;
				customers=customerService.getAllCustomers();
				userInteraction.printCustomerDetails(customers);
			}
			else
				System.out.println("Enter a valid choice");
			
			
			System.out.println("Do you want to add another customer[y/n]");
			c=scan.next().charAt(0);
		}while(c=='y'||c=='Y');
		
		Customer customer;
		do {
		System.out.println("Enter the customer id of the required customer:");
		int customerId=scan.nextInt();
		customer=customerService.findCustomerId(customerId);
		
			
			if(customer!=null)
			{
				System.out.println("1.Create new Account");
				System.out.println("2.Perform Transaction");
				System.out.println("3.Transaction Summary");
				System.out.println("Enter your Choice[1,2,3]?");
				option=scan.nextInt();
				if(option==1)
				{
					
				}
				else if(option==2)
				{
					
				}
				else if(option==3)
				{
					
				}
				else
					System.out.println("Sorry! INvalid choice. Please try Again!");
			}
			else
				System.out.println("Enter a valid customer id");
		}while(customer==null);
		
			
		
		
		

	}

}
