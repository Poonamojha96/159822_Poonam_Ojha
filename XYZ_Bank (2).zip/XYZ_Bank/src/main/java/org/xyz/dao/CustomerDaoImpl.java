package org.xyz.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.xyz.modal.Address;
import org.xyz.modal.Customer;

public class CustomerDaoImpl implements ICustomerDao {

	public List<Customer> customers= dummyDb();
	
	
	
	@Override
	public List<Customer> getAllCustomers() {
		
		return customers;
	}

	private List<Customer> dummyDb() {

		ArrayList<Customer> customers= new ArrayList<>();
		
		customers.add(new Customer(1,"poonam","ojha","poonamojha96@gmail.com","9915155124",
				LocalDate.of(1996, 10, 11),new Address("H.No.1945 St.No.14","Dashmesh Nagar","Ludhiana","Punjab",141003)));
		customers.add(new Customer(2,"tom","singh","tom6@gmail.com","8842326213",
				LocalDate.of(1995, 10, 1),new Address("H.No.132","Uncha Thok","Hardoi","UP",240001)));
		return customers;
	}

	@Override
	public void createCustomer(Customer customer) {
		
		customers.add(customer);
		
	}

	
	
}
