package org.cap.service;

import java.util.List;

import org.cap.dao.ICustomerDBDao;
import org.cap.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("customerDbService")
public class CustomerDBServiceImpl implements ICustomerService {

	@Autowired
	private ICustomerDBDao customerDbDao;

	@Override
	public List<Customer> getAllCustomers() {
		
		return customerDbDao.findAll();
	}

	@Override
	public Customer findCustomer(Integer custId) {
		
		return customerDbDao.findById(custId).get();
	}

	@Override
	public List<Customer> deleteCustomer(Integer custId) {
		
		customerDbDao.deleteById(custId);
		return getAllCustomers();
	}

	@Override
	public List<Customer> createCustomer(Customer customer) {
		
		customerDbDao.save(customer);
		return getAllCustomers();
	}

	@Override
	public List<Customer> updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}
