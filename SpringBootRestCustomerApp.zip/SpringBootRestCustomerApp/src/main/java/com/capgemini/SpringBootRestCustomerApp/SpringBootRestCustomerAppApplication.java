package com.capgemini.SpringBootRestCustomerApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages= {"com.capgemini","org.cap"})
public class SpringBootRestCustomerAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestCustomerAppApplication.class, args);
	}
}
