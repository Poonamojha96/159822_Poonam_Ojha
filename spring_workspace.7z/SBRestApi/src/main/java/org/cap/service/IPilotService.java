package org.cap.service;

import java.util.List;

import org.cap.model.Pilot;

public interface IPilotService {
	public List<Pilot> getAllPilots();
}
