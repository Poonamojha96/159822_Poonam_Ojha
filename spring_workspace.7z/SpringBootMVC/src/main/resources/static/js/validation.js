function validate(){
	var username=document.myForm.userName.value;
	var password=document.myForm.password.value;
	
	if(username=='')
		{
		alert("Please enter username");
			document.getElementById['UserNameErrMsg'].innerHTML="Please enter username";
		}
	else if(password==''){
		document.getElementById['pwdErrMessage'].innerHTML="Please enter password";
	}
	
}